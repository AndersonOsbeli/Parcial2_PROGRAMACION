/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcial2_taller;

/**
 *
 * @author osbel
 */
public class PARCIAL2_TALLER {

    public static void main(String[] args) {
       menu men = new menu();
       men.setVisible(true);
    }
}

﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/mecanicos")]
    [ApiController]
    public class mecanicoController : ControllerBase
    {
        private static List<Models.mecanicos> mecanicos = new List<Models.mecanicos>
        {
            new Models.mecanicos { id = 1, nombre = "Juan", telefono = "123456789" },
            new Models.mecanicos { id = 2, nombre = "Pedro", telefono = "987654321" },
            new Models.mecanicos { id = 3, nombre = "Maria", telefono = "456789123" }
        };
        [HttpGet]
        public ActionResult<List<Models.mecanicos>> GetAll()
        {
            return mecanicos;
        }
    }
}

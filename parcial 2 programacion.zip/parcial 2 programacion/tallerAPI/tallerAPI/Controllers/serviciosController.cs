﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/servicios")]
    [ApiController]
    public class serviciosController : ControllerBase
    {
        private static List<Models.servicios> servicios = new List<Models.servicios>
        {
            new Models.servicios { id = 1, nombre = "Cambio de aceite", precio = 50 },
            new Models.servicios { id = 2, nombre = "Cambio de llantas", precio = 200 },
            new Models.servicios { id = 3, nombre = "Revisión de frenos", precio = 75 }
        };
        [HttpGet]
        public ActionResult<List<Models.servicios>> GetAll()
        {
            return servicios;
        }
    }
}

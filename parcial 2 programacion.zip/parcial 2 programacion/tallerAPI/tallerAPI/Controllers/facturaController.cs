﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class facturaController : ControllerBase
    {
        private static List<Models.factura> facturas = new List<Models.factura>
        {
            new Models.factura { Id = 1, nombreCliente = "Juan", nombreRepuesto = "Aceite" },
            new Models.factura { Id = 2, nombreCliente = "Pedro", nombreRepuesto = "Filtro de aceite" },
        };
        [HttpGet]
        public ActionResult<List<Models.factura>> GetAll()
        {
            return facturas;
        }
    }
}

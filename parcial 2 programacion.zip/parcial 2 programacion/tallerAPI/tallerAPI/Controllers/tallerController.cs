﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class tallerController : ControllerBase
    {
        private static List<Models.taller> talleres = new List<Models.taller>
        {
            new Models.taller { Id = 1, nombre = "Taller A", direccion = "Calle 1" },
            new Models.taller { Id = 2, nombre = "Taller B", direccion = "Calle 2" },
            new Models.taller { Id = 3, nombre = "Taller C", direccion = "Calle 3" }
        };
        [HttpGet]
        public ActionResult<List<Models.taller>> GetAll()
        {
            return talleres;
        }
    }
}

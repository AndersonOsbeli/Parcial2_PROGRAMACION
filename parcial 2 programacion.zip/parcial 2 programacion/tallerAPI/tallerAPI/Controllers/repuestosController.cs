﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class repuestosController : ControllerBase
    {
        private static List<Models.repuestos> repuestos = new List<Models.repuestos>
        {
            new Models.repuestos { id = 1, nombre = "Aceite", precio = 50 },
            new Models.repuestos { id = 2, nombre = "Filtro de aceite", precio = 20 },
            new Models.repuestos { id = 3, nombre = "Bujías", precio = 10 }
        };
        [HttpGet]
        public ActionResult<List<Models.repuestos>> GetAll()
        {
            return repuestos;
        }
    }
}

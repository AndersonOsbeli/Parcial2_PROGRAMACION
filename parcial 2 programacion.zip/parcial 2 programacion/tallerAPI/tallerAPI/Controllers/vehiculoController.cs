﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/vehiculos")]
    [ApiController]
    public class vehiculoController : ControllerBase
    {
        private static List<Models.vehiculos> vehiculos = new List<Models.vehiculos>
        {
            new Models.vehiculos { id = 1, marca = "Toyota", modelo = "Corolla" },
            new Models.vehiculos { id = 2, marca = "Honda", modelo = "Civic" },
            new Models.vehiculos { id = 3, marca = "Ford", modelo = "Focus" }
            };
        [HttpGet]
        public ActionResult<List<Models.vehiculos>> GetAll()
        {
            return vehiculos;
        }
    }
    }


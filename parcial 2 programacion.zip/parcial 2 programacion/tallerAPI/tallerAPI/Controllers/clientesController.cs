﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/clientes")]
    [ApiController]
    public class clientesController : ControllerBase
    {
        private static List<Models.Clientes> clientes = new List<Models.Clientes>
        {
            new Models.Clientes { id = 1, nombre = "Juan", telefono = "123456789" },
            new Models.Clientes { id = 2, nombre = "Pedro", telefono = "987654321" },
            new Models.Clientes { id = 3, nombre = "Maria", telefono = "456789123" }
        };
        [HttpGet]
        public ActionResult<List<Models.Clientes>> GetAll()
        {
            return clientes;
        }
    }
}

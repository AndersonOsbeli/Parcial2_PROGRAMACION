﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Controllers
{
    [Route("api/turnos")]
    [ApiController]
    public class turnosController : ControllerBase
    {
        private static List<Models.turnos> turnos = new List<Models.turnos>
        {
            new Models.turnos { Id = 1, turno = "vespertino", dia = "Lunes" },
            new Models.turnos { Id = 2, turno = "matutino", dia = "Martes" },
        };
        [HttpGet]
        public ActionResult<List<Models.turnos>> GetAll()
        {
            return turnos;
        }
    }
}

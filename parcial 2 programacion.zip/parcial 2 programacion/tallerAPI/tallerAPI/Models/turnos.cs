﻿namespace tallerMecanico.Models
{
    public class turnos
    {
        public int Id { get; set; }
        public string turno { get; set; }
        public string dia { get; set; }

        internal static void Add(turnos newTurno)
        {
            throw new NotImplementedException();
        }
    }
}

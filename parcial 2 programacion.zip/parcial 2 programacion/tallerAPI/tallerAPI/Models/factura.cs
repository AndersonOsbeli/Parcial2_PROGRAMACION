﻿namespace tallerMecanico.Models
{
    public class factura
    {
        public int Id { get; set; }
   
        public string nombreCliente { get; set; }
        public string nombreRepuesto { get; set; }

        internal static void Add(factura newFactura)
        {
            throw new NotImplementedException();
        }

    }
}

﻿namespace tallerMecanico.Models
{
    public class taller
    {
        public int Id { get; set; }
        public string nombre { get; set; }
        public string direccion { get; set; }

        internal static void Add(taller newTaller)
        {
            throw new NotImplementedException();
        }
    }
}

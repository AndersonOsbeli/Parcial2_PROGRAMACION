﻿using Microsoft.AspNetCore.Mvc;

namespace tallerMecanico.Models
{
    public class mecanicos
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public string telefono { get; set; }
       
        internal static void Add(mecanicos newMecanico)
        {
            throw new NotImplementedException();
        }

        
    }
}

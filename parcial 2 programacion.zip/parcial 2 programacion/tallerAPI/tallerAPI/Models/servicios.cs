﻿namespace tallerMecanico.Models
{
    public class servicios
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public double precio { get; set; }
        internal static void Add(servicios newServicio)
        {
            throw new NotImplementedException();
        }
    }
}

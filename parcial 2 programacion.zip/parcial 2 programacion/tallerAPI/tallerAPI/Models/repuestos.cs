﻿namespace tallerMecanico.Models
{
    public class repuestos
    {
        public int id { get; set; }
        public string nombre { get; set; }
        public double precio { get; set; }
        internal static void Add(repuestos newRepuesto)
        {
            throw new NotImplementedException();
        }
    }
}

﻿namespace tallerMecanico.Models
{
    public class vehiculos
    {
        public int id { get; set; }
        public string marca { get; set; }

        public string modelo { get; set; }

        internal static void Add(vehiculos newVehiculo)
        {
            throw new NotImplementedException();
        }

    }
}
